from ebay_scraper import search_ebay
from notifier import send_notification

if __name__ == "__main__":
    results = search_ebay()
    for item in results:
        send_notification(item)

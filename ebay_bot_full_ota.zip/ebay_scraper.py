import requests
from bs4 import BeautifulSoup

def search_ebay():
    URL = "https://www.ebay.com/sch/i.html?_nkw=gaming+laptop&_sop=10"
    headers = {"User-Agent": "Mozilla/5.0"}
    page = requests.get(URL, headers=headers)
    soup = BeautifulSoup(page.content, "html.parser")
    results = []

    for item in soup.select(".s-item"):
        title = item.select_one(".s-item__title")
        price = item.select_one(".s-item__price")
        link = item.select_one(".s-item__link")
        if title and price and link:
            results.append(f"{title.text}
{price.text}
{link['href']}")
    return results

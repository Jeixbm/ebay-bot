import requests
import os
import zipfile
import io

GITHUB_REPO = "Jeixbm/ebay-bot"
BRANCH = "main"
LOCAL_VERSION_FILE = "version.txt"
REMOTE_VERSION_URL = f"https://raw.githubusercontent.com/{GITHUB_REPO}/{BRANCH}/version.txt"
ZIP_URL = f"https://github.com/{GITHUB_REPO}/archive/refs/heads/{BRANCH}.zip"

def get_local_version():
    if not os.path.exists(LOCAL_VERSION_FILE):
        return "0.0.0"
    with open(LOCAL_VERSION_FILE, "r") as f:
        return f.read().strip()

def get_remote_version():
    try:
        r = requests.get(REMOTE_VERSION_URL, timeout=10)
        r.raise_for_status()
        return r.text.strip()
    except Exception as e:
        print("Error fetching remote version:", e)
        return None

def update_bot():
    print("Downloading update...")
    try:
        r = requests.get(ZIP_URL)
        with zipfile.ZipFile(io.BytesIO(r.content)) as zip_ref:
            zip_ref.extractall("/tmp")
        new_folder = f"/tmp/ebay-bot-{BRANCH}"
        os.system(f"cp -r {new_folder}/* ./")
        print("Update completed successfully.")
    except Exception as e:
        print("Update failed:", e)

if __name__ == "__main__":
    local = get_local_version()
    remote = get_remote_version()
    if remote and remote != local:
        print(f"Updating from version {local} to {remote}")
        update_bot()
        with open(LOCAL_VERSION_FILE, "w") as f:
            f.write(remote)
    else:
        print("Bot is up to date.")
